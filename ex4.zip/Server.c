//Import necessary directories
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <pthread.h>
//Define names for the FIFO'S.
#define FIFO_NAME "fifo1"
#define FIFO_NAME2 "fifo2"
#define STR_LEN 100 //Define length for the Buffer.
char s[STR_LEN];//Define char array for message.
int fileR, fileW, retcode;// int variable to keep the index recevied.
pthread_t th;// Variable to keep the thread.
char* Exit1 = "exit";//known key words.
char* done = "done";

void* revstr(void* strr)//Funcation to reverse the word.
{
	// declare variable  
	int i, len, temp;
	char* str1 = (char*)(strr);
	len = strlen(str1); // use strlen() to get the length of str string  
	if (strcmp(str1, Exit1)==0)//IF the commend is 'exit' cancel the oppreation.  
	{
		return((void*)0);
	}
	// use for loop to iterate the string   
	for (i = 0; i < len / 2; i++)
	{
		// temp variable use to temporary hold the string  
		temp = str1[i];
		str1[i] = str1[len - i - 1];
		str1[len - i - 1] = temp;
	}
	fileW = open(FIFO_NAME2, O_WRONLY);//Open fifo2 for writing.
	write(fileW, s, strlen(s) + 1);//writing to fifo.
	close(fileW);//close for writing.
	return((void*)0);//Function ended sucssefully.
}

int main()
{
	// Create two FIFO's  
	if (mkfifo(FIFO_NAME, S_IFIFO | 0644) == -1 &&
		errno != EEXIST)
	{
		perror("cannot create fifo file");
		exit(EXIT_FAILURE);
	}
	if (mkfifo(FIFO_NAME2, S_IFIFO | 0644) == -1 &&
		errno != EEXIST)
	{
		perror("cannot create fifo file");
		exit(EXIT_FAILURE);
	}
	fileR = open(FIFO_NAME, O_RDONLY);
	printf("Server is ready\n");

	while (1)//Infinite Loop
	{
		fileR = open(FIFO_NAME, O_RDONLY);//Open permission to read on FIFO1
		read(fileR, s, STR_LEN);//READ
		if (strlen(s) == 0)// To check if the user clicked on(Ctrl+C) and hence a message in the length of 0 was sent
		{
			close(fileR);//Close permission to read.
			exit(1);//End of task
		}
		if (strcmp(s, Exit1) == 0)//if commend is exit end of task.
		{
			close(fileR); //Close permission to read.
			fileW = open(FIFO_NAME2, O_WRONLY); //Open permission to Write.
			write(fileW, done, strlen(done) + 1); //write to Client.
			close(fileW);//Close permission to write.
			exit(0);//end of task.
		}
		// print the message from the Client 
		printf("Got: %s\n", s);
		//Close permission to read.
			close(fileR);
			//Create thread 
			retcode= pthread_create(&th, NULL, revstr, (void*)(s));
			if (retcode != 0)// IF oppreation has failed print message 
			{
				printf("Create thread failed with error %d\n", retcode);
				exit(1);//End of task.
			}
				
			
	}

	
}