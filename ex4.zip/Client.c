//Import necessary directories
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include<signal.h>
//Declare names for the FIFO'S.
#define FIFO_NAME "fifo1"
#define FIFO_NAME2 "fifo2"
#define STR_LEN 100//Define length for the Buffer.
//Declare Known variabls.
char s[STR_LEN];
int fileR, fileW;
int retcode;
char* done = "done";
//Define function
void PokeBall(int signum)
{
	printf("Signal was sent, end of communication");
	exit(0);
}

int main()
{
	signal(SIGINT, PokeBall);//Check if User type (Ctrl+c) go to Function PokeBall.
	system("clear");//clear the console.
	printf("Enter for the server: ");
	while (1)//Infinite Loop 
	{
		fileW = open(FIFO_NAME, O_WRONLY);//Open permission to Write on FIFO1
		fgets(s, STR_LEN, stdin);//get input from Client.
		fflush(stdin);//clean the Buffer
		strtok(s, "\n");//ignore /n
		write(fileW, s, strlen(s) + 1);//Write to Server
		close(fileW);//Close permission to read.
		fileR = open(FIFO_NAME2, O_RDONLY);//Open permission to Read from FIFO2
		read(fileR, s, STR_LEN);//Read from the Client
		printf("Got From Server: %s", s);
		if (strcmp(s, done) == 0)//if the client got "done" unlike the FIFO'S and close the task.
		{
			if (unlink(FIFO_NAME) == -1)
			{
				printf("FIFO %s has failed to close", FIFO_NAME);
			}
			if (unlink(FIFO_NAME2) == -1)
			{
				printf("%s has failed to close", FIFO_NAME2);
			}
			close(fileR);
			exit(0);
		}
		
	}
}