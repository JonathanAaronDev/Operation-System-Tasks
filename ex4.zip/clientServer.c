#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <signal.h>
#define STR_LEN 100//Max length 
//Known variables 
char* Done1 = "done";
char* Exit1 = "exit";
int my_pipe0[2];//Server--> Writing / Client -->Reading
int my_pipe1[2];//Client--> Writing / Server -->Reading
int status;//int variable to keep the information thats comes from the fork() function and pipe function.
char father_buff[STR_LEN];// char array to keep the string.
//Define function
void PokeBall(int num)
{
	printf("Got Signal\n");
	exit(0);
}
//Funcation to reverse the word.
void revstr(char* str1)
{
	// declare variable  
	int i, len, temp;
	len = strlen(str1); // use strlen() to get the length of str string  

	// use for loop to iterate the string   
	for (i = 0; i < len / 2; i++)
	{
		// temp variable use to temporary hold the string  
		temp = str1[i];
		str1[i] = str1[len - i - 1];
		str1[len - i - 1] = temp;
	}
}
int main()
{

   int my_pipe0[2];//Server--> Writing / Client -->Reading
   int my_pipe1[2];//Client--> Writing / Server -->Reading
   signal(SIGINT, PokeBall);//Check if User type (Ctrl+c) go to Function PokeBall.
   status = pipe(my_pipe0);//Create pipe
   if (status == -1) {
	   printf("Unable to open pipe\n");
	   exit(-1);
   }
   status = pipe(my_pipe1);//Create pipe
   if (status == -1) {
	   printf("Unable to open pipe\n");
	   exit(-1);
   }
   status = fork();//Create son procces
   if (status == -1) {
	   printf("Unable to fork\n");
	   exit(-1);
   }
   if (status == 0) //son procces(Server)
   {
	   close(my_pipe0[0]);//close reading to the Server.
	   close(my_pipe1[1]);//close Writing to the Client.
	   while (1)//infinite loop
	   {
		   read(my_pipe1[0], father_buff, STR_LEN);
		   printf("--Server--\n");
		   if (strlen(father_buff) == 0)//To check if the user clicked on(Ctrl+C) and hence a message in the length of 0 was sent
		   {
			   exit(0); 
		   }
		   if (strcmp(father_buff, "exit") == 0)//if commend is exit end of task.
		   {
			   write(my_pipe0[1], Done1, (strlen(father_buff) + 1) * sizeof(char));//Write to Client
			   exit(0);
		   }
		   printf("Got from client - %s \n", father_buff);
		   revstr((char*)father_buff);//reverse function
		   write(my_pipe0[1], father_buff, (strlen(father_buff) + 1) * sizeof(char));//Write to Client
		   printf("Response sent...\n");
	   }
   }
   else //father procces(Client)
   { 
	   close(my_pipe0[1]); //close Writing to the Server.
	   close(my_pipe1[0]); //close reading to the Client.
	   while (1)
	   {
		   if (strcmp(father_buff, Done1) == 0)//To check if the user clicked on(Ctrl+C) and hence a message in the length of 0 was sent
		   {
			   printf("Goodbye\n");
			   exit(0);
		   }
		   printf("Enter message to server:");
		   scanf("%s", father_buff);
		   write(my_pipe1[1], father_buff, STR_LEN);//Write to Server
		   read(my_pipe0[0], father_buff, STR_LEN);//Read from Client
		   printf("Recevied from Server: %s\n", father_buff);
		  
	   }
   }
}